\'use client\'

import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Image from '@tiptap/extension-image'
import Dropcursor from '@tiptap/extension-dropcursor'
import Placeholder from '@tiptap/extension-placeholder'
import TurndownService from 'turndown'
import { marked } from 'marked'
import { useEffect, useState } from 'react'

const turndownService = new TurndownService()

interface MarkdownEditorProps {
  initialContent: string
  onChange: (markdown: string) => void
}

export default function MarkdownEditor({ initialContent, onChange }: MarkdownEditorProps) {
  const [isMounted, setIsMounted] = useState(false)

  const editor = useEditor({
    extensions: [
      StarterKit,
      Image.configure({
        inline: true,
        allowBase64: false,
      }),
      Dropcursor,
      Placeholder.configure({
        placeholder: 'Write your article or drag and drop images here...',
      }),
    ],
    content: '',
    onUpdate: ({ editor }) => {
      const html = editor.getHTML()
      const markdown = turndownService.turndown(html)
      onChange(markdown)
    },
  })

  useEffect(() => {
    setIsMounted(true)
    if (editor && initialContent) {
      const html = marked.parse(initialContent) as string
      editor.commands.setContent(html)
    }
  }, [editor, initialContent])

  useEffect(() => {
    if (!editor) return

    const handleImageDropOrPaste = async (file: File) => {
      const formData = new FormData()
      formData.append('image', file)

      try {
        const response = await fetch('/api/upload', {
          method: 'POST',
          body: formData,
        })
        const data = await response.json()
        
        if (data.url) {
          editor.chain().focus().setImage({ src: data.url }).run()
        }
      } catch (error) {
        console.error('Image upload failed:', error)
      }
    }

    const view = editor.view
    const dom = view.dom

    const dropListener = (e: DragEvent) => {
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        const file = e.dataTransfer.files[0]
        if (file.type.startsWith('image/')) {
          e.preventDefault()
          handleImageDropOrPaste(file)
        }
      }
    }

    const pasteListener = (e: ClipboardEvent) => {
      if (e.clipboardData && e.clipboardData.files && e.clipboardData.files.length > 0) {
        const file = e.clipboardData.files[0]
        if (file.type.startsWith('image/')) {
          e.preventDefault()
          handleImageDropOrPaste(file)
        }
      }
    }

    dom.addEventListener('drop', dropListener)
    dom.addEventListener('paste', pasteListener)

    return () => {
      dom.removeEventListener('drop', dropListener)
      dom.removeEventListener('paste', pasteListener)
    }
  }, [editor])

  if (!isMounted) return null

  return (
    <div className="border rounded-lg shadow-sm bg-white p-4 min-h-[400px] focus-within:ring-2 focus-within:ring-blue-500">
      <EditorContent editor={editor} className="prose max-w-none focus:outline-none" />
    </div>
  )
}
