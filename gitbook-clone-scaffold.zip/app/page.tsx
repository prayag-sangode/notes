\'use client\'

import { useState } from 'react'
import MarkdownEditor from '@/components/MarkdownEditor'

export default function Home() {
  const [markdown, setMarkdown] = useState('# Welcome to your GitBook Clone\n\nStart typing or drag & drop images right here!')

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-white border-r flex flex-col">
        <div className="p-4 border-b font-bold text-lg text-gray-800">📖 Docs</div>
        <nav className="p-4 space-y-2 flex-1 overflow-y-auto">
          <a href="#" className="block px-3 py-2 rounded bg-blue-50 text-blue-600 font-medium text-sm">Getting Started</a>
          <a href="#" className="block px-3 py-2 rounded text-gray-600 hover:bg-gray-50 text-sm">Architecture Overview</a>
          <a href="#" className="block px-3 py-2 rounded text-gray-600 hover:bg-gray-50 text-sm">API Reference</a>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 bg-white border-b flex items-center justify-between px-8 shadow-sm">
          <h1 className="text-xl font-semibold text-gray-800">Getting Started</h1>
          <button 
            onClick={() => alert('Markdown Saved! Value:\n\n' + markdown)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700"
          >
            Save Changes
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-4xl mx-auto">
            <MarkdownEditor initialContent={markdown} onChange={setMarkdown} />
          </div>
        </div>
      </main>
    </div>
  )
}
