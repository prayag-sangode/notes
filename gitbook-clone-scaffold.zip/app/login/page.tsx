\'use client\'

import { signIn } from "next-auth/react"

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-xl shadow-md text-center">
        <h1 className="text-2xl font-bold tracking-tight text-gray-900">Internal Documentation</h1>
        <p className="text-sm text-gray-500">Sign in using your corporate single sign-on credentials.</p>
        
        <button
          onClick={() => signIn("google", { callbackUrl: "/" })}
          className="w-full py-2.5 px-4 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
        >
          Sign in with Corporate SSO
        </button>
      </div>
    </div>
  )
}
